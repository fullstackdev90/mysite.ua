<?php

use App\Category;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $now = Carbon::now()->toDateTimeString();

        Category::insert([
            ['name' => 'Client', 'slug' => 'laptops', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'Product', 'slug' => 'desktops', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'total', 'slug' => 'mobile-phones', 'created_at' => $now, 'updated_at' => $now],
            ['name' => 'date', 'slug' => 'tablets', 'created_at' => $now, 'updated_at' => $now],
        ]);
    }
}
